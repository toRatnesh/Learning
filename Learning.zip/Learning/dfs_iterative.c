#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 50

typedef struct llist_node
{
	int value;
	struct llist_node * next;
}Node_t;

int dfs_traverse(int arg_sv, int arg_n, int arg_mat[][MAX]);

int stk_push(Node_t ** arg_head, int arg_value);
int stk_pop(Node_t ** arg_head);

int srk_top(Node_t * arg_head);
int stk_empty(Node_t * arg_head);
//int stk_display(Node_t * arg_head);
//int stk_full(Node_t * arg_head);


int main(void)
{
	int n = 0, e = 0, s = -1;
	int src = -1, des= -1;
	
	int i = 0, j = 0;	

	int adj_mat[MAX][MAX];
	
	for(i = 0; i < MAX; i++)
	{
		for(j = 0; j < MAX; j++)
		{
			adj_mat[i][j] = 0;
			
		}
	}
	

	scanf("%d", &n);
	scanf("%d", &e);
	scanf("%d", &s);
	

	for(i = 0; i < e; i++)
	{
		scanf("%d", &src);
		scanf("%d", &des);
		
		adj_mat[src][des] = 1;
	}
/*	
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n; j++)
		{
			printf("%02d ", adj_mat[i][j]);
			
		}
		printf("\n");
	}
*/
	
	dfs_traverse(s, n, adj_mat);
	

	return 0;
}


int dfs_traverse(int arg_sv, int arg_n, int arg_mat[][MAX])
{
	Node_t * head = NULL;
	int * visited = NULL;
	int i = 0;
	
	visited = (int *)malloc(arg_n * sizeof(int));
	if(NULL == visited)
	{
		printf("Error");
		return -1;
	}
	
	for(i = 0; i < arg_n; i++)
	{
		visited[i] = 0;
	}
	
	stk_push(&head, arg_sv);


	while(!stk_empty(head))
	{
		arg_sv = stk_pop(&head);
		if(-1 == arg_sv)
		{
			printf("Error in pop");
			return -1;
		}
		
		if(0 == visited[arg_sv])
		{
			printf("%d ", arg_sv);
			visited[arg_sv] = 1;
		}
		
		for(i = 0; i < arg_n; i++)
		{
			if((0 == visited[i]) && (1 == arg_mat[arg_sv][i]))
			{
				stk_push(&head, i);
			}
		}
	} // end of while
	
	
	
	if(NULL != visited)
	{
		free(visited);
		visited = NULL;
	}

	return 0;
}




int stk_push(Node_t ** arg_head, int arg_value)
{
	Node_t * temp = NULL;
	
	temp = (Node_t *)malloc(sizeof(Node_t));
	if(NULL == temp)
	{
		return -1;
	}
	
	(temp -> value) = arg_value;
	(temp -> next) = (*arg_head);
	
	(*arg_head) = temp;
	
	return 0;	
}

int stk_pop(Node_t ** arg_head)
{
	Node_t * temp = NULL;
	int ret_val = -1;
	
	if(NULL == (*arg_head))
	{
		return -1;
	}
	
	temp = (*arg_head);
	(*arg_head) = ((*arg_head) -> next);
	
	ret_val = (temp -> value);
	
	if(NULL != temp)
	{
		free(temp);
		temp = NULL;
	}
	
	return ret_val;
}

int srk_top(Node_t * arg_head)
{
	return ((NULL != arg_head) ? (arg_head -> value) : -1);
}

int stk_empty(Node_t * arg_head)
{
	return ((NULL == arg_head) ? 1 : 0);
}
/*
int stk_display(Node_t * arg_head)
{
	Node_t * temp = arg_head;
	
	while(NULL != temp)
	{
		printf("%d ", (temp -> value));
		temp = (temp -> next);
	}
	printf("\n");
	
	return 0;
}

*/