#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 50

int dfs_traverse(int arg_v, int arg_n, int arg_mat[][MAX]);
int dfs_traverse_helper(int arg_v, int arg_n, int * arg_visited, int arg_mat[][MAX]);

int main(void)
{
	int n = 0, e = 0, s = -1;
	int src = -1, des= -1;
	
	int i = 0, j = 0;	

	int adj_mat[MAX][MAX];
	
	for(i = 0; i < MAX; i++)
	{
		for(j = 0; j < MAX; j++)
		{
			adj_mat[i][j] = 0;
			
		}
	}
	

	scanf("%d", &n);
	scanf("%d", &e);
	scanf("%d", &s);
	

	for(i = 0; i < e; i++)
	{
		scanf("%d", &src);
		scanf("%d", &des);
		
		adj_mat[src][des] = 1;
	}
/*	
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n; j++)
		{
			printf("%02d ", adj_mat[i][j]);
			
		}
		printf("\n");
	}
*/
	
	dfs_traverse(s, n, adj_mat);
	

	return 0;
}


int dfs_traverse(int arg_src, int arg_n, int arg_mat[][MAX])
{
	int * visited = NULL;
	int i = 0;
	
	visited = (int *)malloc(arg_n * sizeof(int));
	for(i = 0; i < arg_n; i++)
	{
		visited[i] = 0;
	}
	
	dfs_traverse_helper(arg_src, arg_n, visited, arg_mat);
	
	if(NULL != visited)
	{
		free(visited);
		visited = NULL;
	}	
	
	return 0;
}

int dfs_traverse_helper(int arg_v, int arg_n, int * arg_visited, int arg_mat[][MAX])
{
	int i = 0;
	
	arg_visited[arg_v] = 1;
	printf("%d ", arg_v);
	
	for(i = 0; i < arg_n; i++)
	{
		if((0 == arg_visited[i]) && (1 == arg_mat[arg_v][i]))
		{
			dfs_traverse_helper(i, arg_n, arg_visited, arg_mat);
			
		}
	} // end of for

	
	return 0;
}

